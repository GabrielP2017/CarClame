var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/match-remedy/route.js")
R.c("server/chunks/node_modules_next_8b702a60._.js")
R.c("server/chunks/[root-of-the-server]__5d498a9c._.js")
R.m("[project]/.next-internal/server/app/api/match-remedy/route/actions.js [app-rsc] (server actions loader, ecmascript)")
R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/match-remedy/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/app-route.js { INNER_APP_ROUTE => \"[project]/src/app/api/match-remedy/route.ts [app-route] (ecmascript)\" } [app-route] (ecmascript)").exports
