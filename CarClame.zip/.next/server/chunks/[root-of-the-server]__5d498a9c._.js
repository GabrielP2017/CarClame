module.exports = [
"[project]/.next-internal/server/app/api/match-remedy/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/action-async-storage.external.js [external] (next/dist/server/app-render/action-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/action-async-storage.external.js", () => require("next/dist/server/app-render/action-async-storage.external.js"));

module.exports = mod;
}),
"[project]/src/lib/timeMileage.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/timeMileage.ts
__turbopack_context__.s([
    "daysSince",
    ()=>daysSince,
    "ddayLabel",
    ()=>ddayLabel,
    "kmLeftLabel",
    ()=>kmLeftLabel,
    "mileageDelta",
    ()=>mileageDelta,
    "normalizeDate",
    ()=>normalizeDate,
    "todayLocal",
    ()=>todayLocal,
    "window2000km",
    ()=>window2000km,
    "window30d",
    ()=>window30d,
    "window3d",
    ()=>window3d,
    "window7d",
    ()=>window7d,
    "window90d",
    ()=>window90d
]);
const DAY_MS = 24 * 60 * 60 * 1000;
function parseLocalDate(yyyyMmDd) {
    if (!yyyyMmDd) return null;
    const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(yyyyMmDd);
    if (!m) return null;
    const y = +m[1], mon = +m[2] - 1, d = +m[3];
    const dt = new Date(y, mon, d);
    if (dt.getFullYear() !== y || dt.getMonth() !== mon || dt.getDate() !== d) return null;
    return dt;
}
function startOfDay(d) {
    return new Date(d.getFullYear(), d.getMonth(), d.getDate());
}
function todayLocal() {
    return startOfDay(new Date());
}
function normalizeDate(yyyyMmDd) {
    const t = todayLocal();
    const p = parseLocalDate(yyyyMmDd) ?? t;
    return p > t ? t : p;
}
function daysSince(yyyyMmDd) {
    const t = todayLocal().getTime();
    const p = normalizeDate(yyyyMmDd).getTime();
    return Math.floor((t - p) / DAY_MS);
}
function ddayLabel(targetDays, elapsedDays) {
    const remain = targetDays - elapsedDays;
    return remain >= 0 ? `D-${remain}` : `D+${Math.abs(remain)}`;
}
function mileageDelta(purchaseMileage, currentMileage) {
    if (purchaseMileage == null || isNaN(purchaseMileage)) return null;
    const used = Math.max(0, Math.round(currentMileage) - Math.round(purchaseMileage));
    return used;
}
function kmLeftLabel(limitKm, usedKm) {
    if (usedKm == null) return {
        kmLeft: null,
        label: "미입력"
    };
    const left = limitKm - usedKm;
    return {
        kmLeft: left,
        label: left >= 0 ? `남은 ${left}km` : `초과 ${Math.abs(left)}km`
    };
}
function window30d(purchaseDate) {
    const elapsed = daysSince(purchaseDate);
    return {
        daysLeft: 30 - elapsed,
        label: ddayLabel(30, elapsed)
    };
}
function window3d(purchaseDate) {
    const elapsed = daysSince(purchaseDate);
    return {
        daysLeft: 3 - elapsed,
        label: ddayLabel(3, elapsed)
    };
}
function window7d(purchaseDate) {
    const elapsed = daysSince(purchaseDate);
    return {
        daysLeft: 7 - elapsed,
        label: ddayLabel(7, elapsed)
    };
}
function window90d(purchaseDate) {
    const elapsed = daysSince(purchaseDate);
    return {
        daysLeft: 90 - elapsed,
        label: ddayLabel(90, elapsed)
    };
}
function window2000km(purchaseMileage, currentMileage) {
    const used = mileageDelta(purchaseMileage, currentMileage);
    return kmLeftLabel(2000, used);
}
}),
"[project]/src/lib/rules.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/lib/rules.ts
// 규칙 엔진: 입력(사진·OCR 없어도 됨)만으로
// - 책임보험(30일/2,000km)
// - 판매사 환불(K Car 3일 / 엔카 7일)
// - 개인보험(공통서류 안내)
// - D-day/남은 km 라벨
// - 팩트체크 카드 기본값
// 을 산출하여 1단계에서 합의한 출력 스키마로 반환합니다.
__turbopack_context__.s([
    "evaluateAll",
    ()=>evaluateAll
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/timeMileage.ts [app-route] (ecmascript)");
;
// ====== 내부 도움 함수 ======
// 책임보험 판정 라벨을 날짜/주행 조건 조합으로 생성
function verdictByDayKm(dayOk, kmOk) {
    if (dayOk && (kmOk === true || kmOk === null)) return "가능성 높음";
    if (!dayOk && kmOk === false) return "기간/주행 초과";
    if (!dayOk) return "기간 초과"; // kmOk가 true 또는 null
    return "주행 초과"; // dayOk 이고 kmOk === false
}
// 이유 문구 생성(설명 통일)
function buildLiabilityReason(elapsedDays, usedKm) {
    const dayPart = `구매 ${elapsedDays}일 경과`;
    const kmPart = usedKm == null ? "주행거리 미입력 → km 판정 제외" : `구매 후 주행 ${usedKm}km`;
    return `${dayPart}. ${kmPart}`;
}
// 판매사 환불 판정(브랜드별 3일/7일 적용)
function evaluateDealerRefund(purchaseChannel, elapsedDays) {
    if (purchaseChannel === "K Car") {
        const dayOk = elapsedDays <= 3;
        return {
            verdict: dayOk ? "가능성 높음" : "기간 초과",
            reason: dayOk ? "K Car 3일 환불 정책 창구 대상 가능성" : "K Car 3일 환불 정책 기간 초과",
            brand: "K Car",
            windowDays: 3
        };
    }
    if (purchaseChannel === "엔카") {
        const dayOk = elapsedDays <= 7;
        return {
            verdict: dayOk ? "가능성 높음" : "기간 초과",
            reason: dayOk ? "엔카 7일 환불 정책 창구 대상 가능성" : "엔카 7일 환불 정책 기간 초과",
            brand: "엔카",
            windowDays: 7
        };
    }
    // 개인/기타 채널: 판매사 환불 정책 비대상 → 표준 라벨 '검토 필요' 적용
    return {
        verdict: "검토 필요",
        reason: "개인/기타 채널은 판매사 환불 정책 대상이 아님 — 다른 구제수단(책임보험/개인보험) 검토 필요"
    };
}
// 팩트체크 카드 기본값(외부 연동/AI 없을 때도 빈칸 방지)
function buildFactCheckDefaults() {
    return {
        history: {
            status: "불명",
            summary: "외부 이력 미연동(목업)",
            evidence: []
        },
        ocr: {
            status: "확인 불가",
            summary: "기록부 이미지/텍스트 미제공",
            evidence: []
        },
        photo: {
            status: "업로드 없음",
            summary: "점검 사진 미제공"
        }
    };
}
function evaluateAll(input) {
    // 1) 기본 D-day/주행 윈도우 계산
    const d30 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["window30d"])(input.purchaseDate);
    const d3 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["window3d"])(input.purchaseDate);
    const d7 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["window7d"])(input.purchaseDate);
    const d90 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["window90d"])(input.purchaseDate);
    const km2000 = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["window2000km"])(input.purchaseMileage ?? null, input.currentMileage);
    // 2) 책임보험(30일/2,000km) 판정
    const elapsedDays = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["daysSince"])(input.purchaseDate);
    const usedKm = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$timeMileage$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["mileageDelta"])(input.purchaseMileage ?? null, input.currentMileage);
    const dayOk = elapsedDays <= 30;
    const kmOk = usedKm == null ? null : usedKm <= 2000;
    const liabilityVerdict = verdictByDayKm(dayOk, kmOk);
    const liabilityReason = buildLiabilityReason(elapsedDays, usedKm);
    // 3) 판매사 환불 판정
    const dealer = evaluateDealerRefund(input.purchaseChannel, elapsedDays);
    // 4) 개인보험(기본: 검토 필요 + 공통 서류 안내)
    const personal = {
        verdict: "검토 필요",
        reason: "개인 자동차보험 청구는 사건 유형별로 상이. 공통 서류 안내 필요"
    };
    // 5) 팩트체크 카드(기본값)
    const fact = buildFactCheckDefaults();
    // 6) 불일치/경고 플래그(3단계에서는 기본 없음)
    const flags = [];
    return {
        factCheck: fact,
        flags,
        remedies: {
            liabilityInsurance: {
                verdict: liabilityVerdict,
                reason: liabilityReason
            },
            dealerRefund: dealer,
            personalInsurance: personal
        },
        deadlines: {
            d30,
            km2000,
            d3,
            d7,
            d90
        }
    };
}
}),
"[project]/src/app/api/match-remedy/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

// src/app/api/match-remedy/route.ts
// 입력(JSON) → 규칙 엔진 → 표준 응답(JSON)
// 사진/ocr 미제공이어도 빈칸 없이 항상 채워진 응답을 반환합니다.
__turbopack_context__.s([
    "POST",
    ()=>POST,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rules$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/rules.ts [app-route] (ecmascript)");
;
;
async function POST(req) {
    try {
        const body = await req.json();
        const { vehicleId, purchaseDate, currentMileage, purchaseMileage = null, purchaseChannel, ocrText, carImages } = body ?? {};
        // --- 최소 유효성 검사(필수 필드) ---
        const channels = [
            "개인",
            "K Car",
            "엔카",
            "기타"
        ];
        const valid = typeof vehicleId === "string" && typeof purchaseDate === "string" && (typeof currentMileage === "number" || typeof currentMileage === "string") && channels.includes(purchaseChannel);
        if (!valid) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: "invalid_request",
                message: "필수 필드(vehicleId, purchaseDate, currentMileage, purchaseChannel)를 확인하세요."
            }, {
                status: 400
            });
        }
        // --- 수치 정규화(음수 방지/정수화) ---
        const currentKm = Math.max(0, Math.round(Number(currentMileage)));
        const purchaseKm = purchaseMileage == null || purchaseMileage === "" ? null : Math.max(0, Math.round(Number(purchaseMileage)));
        const input = {
            vehicleId,
            purchaseDate,
            currentMileage: currentKm,
            purchaseMileage: purchaseKm,
            purchaseChannel,
            ocrText,
            carImages
        };
        const result = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$rules$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["evaluateAll"])(input);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json(result, {
            status: 200
        });
    } catch  {
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            error: "bad_json",
            message: "JSON 본문을 확인하세요."
        }, {
            status: 400
        });
    }
}
const dynamic = "force-dynamic";
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5d498a9c._.js.map